export const tamesu = (strUrl) => {
  const a =
    "http://res.cloudinary.com/dhbnknlos/image/upload/c_thumb,g_faces,h_250,w_250/r_max/co_rgb:F8F3F0,e_outline:10/b_rgb:DBE0EA/happy_people";
  return a;
};
